import React from 'react'

export default class GreenHouse{

constructor(nameGreenHouse,numberGreenHouse){
    
    this.nameGreenHouse = nameGreenHouse;
    this.numberGreenHouse = numberGreenHouse
  
}
  
}
